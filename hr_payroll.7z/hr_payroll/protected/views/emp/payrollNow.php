<?php
/* @var $this EmpController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Emps',
);

$this->menu=array(
	//array('label'=>'Create Emp', 'url'=>array('create')),
	array('label'=>'None', 'url'=>array('emp/account', 'id'=>yii::app()->user->name)),
);
?>

<h1><?php echo $model->name;?></h1>

<?php
echo "Ontime : ".$ontime;
echo "<br> Dinas Luar : ".$dinas_luar;
?>