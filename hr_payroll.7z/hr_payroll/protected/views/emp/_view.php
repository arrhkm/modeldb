<?php
/* @var $this EmpController */
/* @var $data Emp */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::encode($data->id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('name')); ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('gender')); ?>:</b>
	<?php 
		if($data->gender=="f") 
			$gender = "female"; else $gender = "male"; 
		
	echo CHtml::encode($gender); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('start_job')); ?>:</b>
	<?php echo CHtml::encode($data->start_job); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('warm_contract')); ?>:</b>
	<?php echo CHtml::encode($data->warm_contract); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('warm_date')); ?>:</b>
	<?php echo CHtml::encode($data->warm_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('citizen_id')); ?>:</b>
	<?php echo CHtml::encode($data->citizen_id); ?>
	<br />

	
	<b><?php echo CHtml::encode($data->getAttributeLabel('jamsostek_id')); ?>:</b>
	<?php echo CHtml::encode($data->jamsostek_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('bank_account')); ?>:</b>
	<?php echo CHtml::encode($data->bank_account); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('npwp')); ?>:</b>
	<?php echo CHtml::encode($data->npwp); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('gp')); ?>:</b>
	<?php echo CHtml::encode("Rp. ".number_format($data->gp, 2, ',','.')); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tmasakerja')); ?>:</b>
	<?php //echo CHtml::encode($data->tmasakerja); ?>
	<?php echo CHtml::encode("Rp. ".number_format($data->tmasakerja,2, ',','.')); ?>
	<?php //echo CHtml::encode(Yii::app()->format->number($data->tmasakerja)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tjabatan')); ?>:</b>
	<?php echo CHtml::encode("Rp. ". number_format($data->tjabatan, 2, ',','.')); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('tfunctional')); ?>:</b>
	<?php echo CHtml::encode("Rp. ".number_format($data->tfunctional, 2, ',','.')); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('allowance')); ?>:</b>
	<?php echo CHtml::encode("Rp. ".number_format($data->allowance, 2, ',','.')); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('premi_hadir')); ?>:</b>
	<?php echo CHtml::encode("Rp. ".number_format($data->premi_hadir, 2, ',','.')); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('email')); ?>:</b>
	<?php echo CHtml::encode($data->email); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('partjob_id')); ?>:</b>
	<?php $part= Partjob::model()->findByPk($data->partjob_id);?>
	<?php echo CHtml::encode($data->partjob_id); ?>
	<?php echo CHtml::encode($part->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('jobtitle_id')); ?>:</b>
	<?php $jobtitle = Jobtitle::model()->findByPk($data->jobtitle_id);?>
	<?php echo CHtml::encode($data->jobtitle_id); ?>
	<?php echo CHtml::encode($jobtitle->name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('officetime_id')); ?>:</b>
	<?php $officetime= Officetime::model()->findByPk($data->officetime_id);?>
	<?php echo CHtml::encode($data->officetime_id); ?>
	<?php echo CHtml::encode($officetime->name_time); ?>
	<br />

	 

</div>