<?php
/* @var $this EmpController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Emps',
);

$this->menu=array(	
	//array('label'=>'None', 'url'=>array('emp/account', 'id'=>yii::app()->user->name)),
	array('label'=>'Change Password', 'url'=>array('/user/changepassword', 'id'=>yii::app()->user->id)),
);
?>

<h1><?php echo $model->name;?></h1>

<?php 
/*$this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); 

*/?>

<?php 

$this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'name',
		'gender',
		'start_job',
		'warm_contract',
		'warm_date',
		'citizen_id',
		'jamsostek_id',
		'bank_account',
		'npwp',
		//'gp',
		array(
			'name'=>'Gaji Pokok',           
			'value'=>CHtml::encode(yii::app()->hakamFormat->formatNumber($model->gp)),
		),
		array(
			'name'=>'Tunjangan Masa kerja',           
			'value'=>CHtml::encode(yii::app()->hakamFormat->formatNumber($model->tmasakerja)),
		),
		array(
			'name'=>'tjabatan',           
			'value'=>CHtml::encode(yii::app()->hakamFormat->formatNumber($model->tjabatan)),
		),
		array(
			'name'=>'tfunctional',           
			'value'=>CHtml::encode(yii::app()->hakamFormat->formatNumber($model->tfunctional)),
		),
		array(
			'name'=>'allowance',           
			'value'=>CHtml::encode(yii::app()->hakamFormat->formatNumber($model->allowance)),
		),
		array(
			'name'=>'premi_hadir',           
			'value'=>CHtml::encode(yii::app()->hakamFormat->formatNumber($model->premi_hadir)),
		),
		/*'tmasakerja',
		'tjabatan',
		'tfunctional',
		'allowance',
		'premi_hadir',*/
		'email',
		'partjob_id',
		'jobtitle_id',
		'officetime_id',
	),
)); 

?>
