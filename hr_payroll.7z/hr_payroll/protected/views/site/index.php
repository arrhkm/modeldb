<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>



<p>You may see the content of your Payroll  by HRD PT. Lintech Duta Pratama:</p>
<ul>
	<li>View Payroll in Period </li>
	<li>View Cuti</li>
	<li>View Day Off in period </li>
	<li>View Account</li>
</ul>

<p>For more details on how to surfing this application, please contact to IT PT. Lintech Duta Pratama 
hakam@lintech.co.id or rianto_halim@lintech.co.id, should you have any questions.</p>
