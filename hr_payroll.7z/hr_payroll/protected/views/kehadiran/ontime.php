<?php
/* @var $this KehadiranController */

$this->breadcrumbs=array(
	'Kehadiran',
);


$this->menu=array(
	//array('label'=>'Kehadiran by date', 'url'=>array('bydate')),
	//array('label'=>'Manage Emp', 'url'=>array('admin')),
);

?>
<p><?php echo "jumlah Selisih : ".$hari;?></p>

