<?php
/* @var $this DetilcutiController */
/* @var $model Detilcuti */

$this->breadcrumbs=array(
	'Cuti'=>array('cuti/'),
	'Create',
);

$this->menu=array(
	//array('label'=>'List Detilcuti', 'url'=>array('index')),
	//array('label'=>'Manage Detilcuti', 'url'=>array('admin')),
);
?>

<h1>Create Detilcuti</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>
<?php 
$modelDetil= new Detilcuti;
$criteria= new CDbCriteria;
		/*$criteria->compare('id',$id);
		$criteria->compare('cuti_id',$cuti_id);
		$criteria->compare('cuti_emp_id',$cuti_emp_id,true);
		$criteria->compare('kodecuti_id',$kodecuti_id);
		$criteria->compare('date_cuti',$date_cuti,true);
		*/
		$criteria->select= '*';
		$criteria->condition= 'cuti_id='.$_REQUEST[detilcuti_id];
		$detilProvider = new CActiveDataProvider($modelDetil, array(
			'criteria'=>$criteria,
		));
$this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'detilcuti-grid',
	'dataProvider'=>$detilProvider, //$model->detil($_GET[emp_id]),
	//'filter'=>$model,
	'columns'=>array(
		'id',
		'cuti_id',
		'cuti_emp_id',
		'kodecuti_id',
		'date_cuti',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); 
?>