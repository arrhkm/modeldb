<div class="form">
 
<?php $form = $this->beginWidget('CActiveForm', array(
            'id' => 'chnage-password-form',
            'enableClientValidation' => true,
            'htmlOptions' => array('class' => 'well'),
            'clientOptions' => array('validateOnSubmit' => true,),
     ));
?>
 
  <div class="row"> 
    <?php echo $form->labelEx($model,'old_password'); ?> 
    <?php echo $form->passwordField($model,'old_password'); ?> 
    <?php echo $form->error($model,'old_password'); ?>
  </div>
 
  <div class="row"> 
    <?php echo $form->labelEx($model,'new_password'); ?> 
    <?php echo $form->passwordField($model,'new_password'); ?> 
    <?php echo $form->error($model,'new_password'); ?> 
  </div>
 
  <div class="row"> 
    <?php echo $form->labelEx($model,'repeat_password'); ?> 
    <?php echo $form->passwordField($model,'repeat_password'); ?> 
    <?php echo $form->error($model,'repeat_password'); ?> 
  </div>
 
  <div class="row submit">
    <?php //$this->widget('bootstrap.widgets.TbButton', array('buttonType' => 'submit', 'type' => 'primary', 'label' => 'Change password')); ?>
    <?php echo CHtml::submitButton('Change Password'); ?>
  </div>
  <?php $this->endWidget(); ?>
</div>
<?php echo $msg;?>
<?php 

//echo "<br> old: ".$model->old_password;
//echo "<br> new : ".$model->new_password;
//echo "<br> repeat : ".$model->repeat_password;
//echo "<br> Id : ".$model->id;
//echo "<br> Id : ".$model->user_password;

?>