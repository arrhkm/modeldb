<?php 
$testvar= json_encode($dt);

$length = 10;
$chars = array_merge(range(0,9), range('a','z'), range('A','Z'));
shuffle($chars);
$password = implode(array_slice($chars, 0, $length));
$password2 = Yii::app()->epassgen->generate();
$password3= yii::app()->hkmpass->generate();
echo $password;
echo "<br> pass 2 : ".$password2;
echo "<br> pass 3 : ".$password3;

?>