<?php 

$this->menu=array(	
    array('label'=>'view Period', 'url'=>array('period/view', 'id'=>$model->id)),
    //array('label'=>'Payroll', 'url'=>array('period/payroll', 'periodId'=>$model->id)),
	//array('label'=>'Cuti', 'url'=>array('viewCuti', 'periodId'=>$model->id)),
	//array('label'=>'Telat', 'url'=>array('telat', 'periodId'=>$model->id)),
   
	//array('label'=>'Delete Period', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	
	//array('label'=>'Day Off Period', 'url'=>array('dayoff', 'dayoff_id'=>$model->id)),
    //array('label'=>'Late In Period', 'url'=>array('latePeriod', 'periodId'=>$model->id)),
);

$this->widget('zii.widgets.grid.CGridView', array(
    'dataProvider'=>$dataProvider,
));

?>