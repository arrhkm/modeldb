<?php 

$this->menu=array(	
   array('label'=>'view Period', 'url'=>array('period/view', 'id'=>$model->id)),
    
);

$this->widget('zii.widgets.grid.CGridView', array(
    'dataProvider'=>$dataProvider,
));

?>