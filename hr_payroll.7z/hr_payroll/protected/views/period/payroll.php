<?php

$this->menu=array(
	array('label'=>'view Period', 'url'=>array('period/view', 'id'=>$periodId)),
	//array('label'=>'Payroll', 'url'=>array('period/payroll', 'periodId'=>$periodId)),
	//array('label'=>'Cuti', 'url'=>array('viewCuti', 'periodId'=>$periodId)),
	//array('label'=>'Telat', 'url'=>array('telat', 'periodId'=>$periodId)),
);
?>

<h1>Payroll</h1>
<?php
$total=0;
foreach ($dt as $key=>$value){
	echo "---------------------------------------------------------------------------------------|<br>";
	$total = $value['biayaPremi']+$value['gp']+$value['allowance']+$value['tmasakerja']+$value['tjabatan']+$value['tfunctional']+$value['insentif']+$value['dapen']-($value['angsuran']);	
	echo "| Id => ".$value[emp_id]."<br>";
	echo "| name => ".$value[name]."<br>";
	echo "|---------------------------------------------------------------------------------------<br>";
	//echo " Jumlah premi hadir=> ".$value['jml']."<br>";
	//echo " Jmulah dinas luar => ".$value['dinas']."<br>";
	echo " Total Premi => ".$value['totalPremi']."<br>";
	echo " Biaya Premi => ".yii::app()->hakamFormat->formatNumber($value['biayaPremi'])."<br>";
	echo " Gaji Pokok => ".yii::app()->hakamFormat->formatNumber($value['gp'])."<br>";
	echo " Allowence => ".yii::app()->hakamFormat->formatNumber($value['allowance'])."<br>";
	echo " T. Masakerja => ".yii::app()->hakamFormat->formatNumber($value['tmasakerja'])."<br>";
	echo " T. Jabatan => ".$value['tjabatan']."<br>";
	echo " T. Functional => ".yii::app()->hakamFormat->formatNumber($value['tfunctional'])."<br>";
	echo " Insentif = >".Convert::NumberToMoney($value[insentif])."<br>";
	echo " Dapen = >".Convert::NumberToMoney($value[dapen])."<br>";
	echo " --------------------------------------------------------------------------------------<br>";
	echo " <br>";
	
	echo " Kasbon = >".Convert::NumberToMoney($value[kasbon])."<br>";
	echo " Angsuran ke = >".$value[no_angsuran]."<br>";
	echo " Nilai Angusan = >".Convert::NumberToMoney($value[angsuran])."<br>";
	echo " Total angsuran = >".Convert::NumberToMoney($value[total_angsuran])."<br>";
	echo " Sisa Angsuran =>".Convert::NumberToMoney($value[sisa_kasbon]). "<br>";
	echo " --------------------------------------------------------------------------------------<br>";
	echo " <br> ";

	echo " Total Gaji => ".yii::app()->hakamFormat->formatNumber($total)."<br>";
	echo " --------------------------------------------------------------------------------------<br>";
	echo " <br>";

	echo " <br>";
	echo " Telat => ".$value['telat']."<br>";
	echo " lupa ID => ".$value['lupa_id']."<br>";
	echo " tdk Masuk => ".$value['notin_work']."<br>";
	echo " Cuti => ".$value['cuti']."<br>";
	echo "---------------------------------------------------------------------------------------<br>";
	$total=0;
} 
?> 
