<?php 

$this->menu=array(	
   array('label'=>'view Period', 'url'=>array('period/view', 'id'=>$model->id)),
    
);
?>
<h1>Terlambat Kerja </h1>
<?php 
$this->widget('zii.widgets.grid.CGridView', array(
    'dataProvider'=>$dataProvider,
));
?>

<h1>Tidak Bawa Card ID </h1>
<?php 
$this->widget('zii.widgets.grid.CGridView', array(
    'dataProvider'=>$ijinProvider,
));

?>