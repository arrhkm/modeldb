<?php

/**
 * This is the model class for table "user".
 *
 * The followings are the available columns in table 'user':
 * @property integer $id
 * @property string $user_name
 * @property string $user_password
 * @property integer $user_level
 */
class User extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	
	public $password;//tambahan
	public $password_repeat;//tambahan

	public $old_password;
    public $new_password;
    public $repeat_password;
	
	public function tableName()
	{
		return 'user';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			 //array('user_name, password', 'required'),
			 //array('user_name', 'ECompositeUniqueValidator'),
			 array('user_name', 'unique'),
			 array('user_name', 'length', 'min'=>3, 'max'=>32),
			 //array('password, password_repeat', 'required', 'on' => 'passwordset'),
			 //array('password', 'length', 'min'=>8, 'max'=>35, 'on' => 'passwordset'),

			 array('old_password, new_password, repeat_password', 'required', 'on' => 'changePwd'),
        	 array('old_password', 'findPasswords', 'on' => 'changePwd'),
        	 array('repeat_password', 'compare', 'compareAttribute'=>'new_password', 'on'=>'changePwd'),

			// array('password', 'compare', 'compareAttribute' => 'password_repeat'),
			 array('user_name, password, password_repeat', 'safe'),
			 array('user_level', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_name, user_password, user_level', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_name' => 'User Name',
			'user_password' => 'User Password',
			'user_level' => 'User Level',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('user_name',$this->user_name,true);
		$criteria->compare('user_password',$this->user_password,true);
		$criteria->compare('user_level',$this->user_level);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	public function validatePassword($password){
		//$model= New UserAdmin;
		if ($this->user_password === md5($password)) 
		return true;
	}
	public function findPasswords($attribute, $params)
    {
        $user = User::model()->findByPk(yii::app()->user->id);
        if ($user->user_password  !== md5($this->old_password))
        {       
            $this->addError($attribute, 'Old password is incorrect.');
        }
    }
	

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return User the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function beforeValidate()
	{
		parent::beforeValidate();
	   //NewPartjob = new Partjob();
	   	if($this->isNewRecord)
	   	{
	    	$criteria=new CDbCriteria;      //kita menggunakan criteria untuk mengetahui nomor terakhir dari database
	     	$criteria->select = 'id';   //yang ingin kita lihat adalah field "nilai1"
	     	$criteria->limit=1;             // kita hanya mengambil 1 buah nilai terakhir
		    $criteria->order='id DESC';  //yang dimbil nilai terakhir
		    $last = $this->find($criteria);
	     	if($last)   // jika ternyata ada nilai dalam data tersebut maka nilai nya saat ini tinggal di tambah 1 dari data sebelumya
	     	{
		       $newID = (int)$last->id+ 1;
		       //$newID = 'sabit-'.$newID;
	     	}
	     	else  //jika ternyata pada tabel terebut masih kosong, maka akan di input otomatis nilai "sabit-1" karena memang belum ada sebelumnya nilai lain
	     	{
	       		$newID = 1;
	     	}
	     	$this->id=$newID; // nilai1 di set nilai yang sudah di dapat tadi
	  	} 
	  	return true;
	}
}
