<?php

class RegisterUserController extends Controller
{
	public function actionIndex()
	{
		$this->render('index');
	}

	public function actionRegister()
	{
	    $model=new RegisterForm('register');

	    // uncomment the following code to enable ajax-based validation
	    /*
	    if(isset($_POST['ajax']) && $_POST['ajax']==='emp-register-form')
	    {
	        echo CActiveForm::validate($model);
	        Yii::app()->end();
	    }
	    */

	    if(isset($_POST['RegisterForm']))
	    {
	        $model->attributes=$_POST['RegisterForm'];
	        if($model->validate())
	        {
	            $mEmp= Emp::model()->findByAttributes(array('id'=>$model->id, 'email'=>$model->email));
	            if ($mEmp->id){
	            	$msg = "Data ditemukan";
	            	$passwd= Yii::app()->hkmpass->generate();
	            	$mUser= User::model()->findByAttributes(array('user_name'=>$mEmp->id));
	            	if($mUser-id){

	            		$mUser->user_password=md5($passwd);
	            		$mUser->user_level = 0;
	            		$mUser->save();
	            		$msg= "data di Update dan password dikirim ke email anda ";
	            		
	            		$body .= "Emp id: " .  $mEmp->id  ." Password : ". $passwd ."   \n";
						$body .= "------------------------------------------------------------\n";
						$body .= "Login : http://192.168.100.111/hr_payroll/index.php?r=site/login \n"; 
						$body .= "\n Kerahasiaan data payroll ada di tangan anda. Silahkan gunakan dengan sebaik-baiknya, untuk lebih aman disarankan password segera dirubah \n";
	            		$kirimi ='Payroll';						 
						$mailTo = $model->email; //test email kirim lintech						
						$subject = "Password HR-Payroll";
						$headers = 'From: <'.$mailTo.'> ' . "\r\n" . 'Reply-To: ' . $mailTo;
						$headers = 'Form: <'.$kirimi.'> ' . "\r\n" . 'Reply-To: ' . $kirimi;
						mail($mailTo, $subject, $body, $headers);

	            	} else {
	            		$mUser= New User;
	            		$mUser->user_name=$mEmp->id;
	            		$mUser->user_password=md5($passwd);
	            		$mUser->user_level= 0;
	            		$mUser->save();
	            		$msg= "data di Insert dan password dikirim ke email anda ";

	            		$body .= "  Emp id: " .  $mEmp->id  ." Password : ". $passwd ."   \n";
						$body .= "------------------------------------------------------------\n"; 
						$body .= "Login : http://192.168.100.111/hr_payroll/index.php?r=site/login \n"; 
						$body .= "\n Kerahasiaan data payroll ada di tangan anda. Silahkan gunakan dengan sebaik-baiknya, untuk lebih aman disarankan password segera dirubah \n";
	            		$kirimi ='Payroll';						 
						$mailTo = $mEmp->email; //test email kirim lintech						
						$subject = "Password HR-Payroll";
						$headers = 'From: <'.$mailTo.'> ' . "\r\n" . 'Reply-To: ' . $mailTo;
						$headers = 'Form: <'.$kirimi.'> ' . "\r\n" . 'Reply-To: ' . $kirimi;
						mail($mailTo, $subject, $body, $headers);
	            	}

	            } else {
	            	$msg= "Data tdk ditemukan atau email anda tidak terdaftar";
	            }
	        }
	    }
	    $this->render('register',array('model'=>$model, 'msg'=>$msg));
	}
}